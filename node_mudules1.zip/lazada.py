#!/usr/bin/python
# bomber lazada || 23-12-2017
# gunakan ini sebagai pembelajaran saja!
import lazada_bomber


