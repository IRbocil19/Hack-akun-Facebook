#!/usr/bin/bash

#Semangat untuk meraih sukses
#belajar seara otodidak memang sangat sususah
#Cie ada yg mau nge record tools gue
#jika lu ingin nge record tools gue lu harus
#minta ijin dl ke gue kotank wa : 083879017166 
#kalo gk ijin dl lu gk akan bisa success

clear
echo "loAding........../";

sleep 0.1;

clear

echo $yellow

echo 'loaDing..........-';

sleep 0.1;

clear

echo  $cyan

echo 'loadIng..........\';

sleep 0.1;

clear

echo  $red

echo "loadiNg........../";

sleep 0.1;

clear

echo  $green

echo "loadinG..........-";

sleep 0.1;

clear

echo  $yellow

echo 'loading..........\';

sleep 0.1;

clear

echo  $cyan

echo 'Loading..........-';

sleep 0.1;

clear

echo  $red

echo "lOading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding............-';

sleep 0.1;

clear

echo  $yellow

echo 'loaDing.............\';

sleep 0.1;

clear

echo  $cyan

echo "loadIng............./";

sleep 0.1;

clear 

echo  $red

echo "loading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding..........-';

sleep 0.1;

clear

echo  $yellow

echo 'lOading..........\';

sleep 0.1;

clear

echo  $cyan

echo "Loading........../";

sleep 0.1;

clear

echo  $green

echo "loAding........../";

sleep 0.1;

clear

echo  $yellow

echo 'loaDing..........-';

sleep 0.1;

clear

echo  $cyan

echo 'loadIng..........\';

sleep 0.1;

clear

echo  $red

echo "loadiNg........../";

sleep 0.1;

clear

echo  $green

echo "loadinG..........-";

sleep 0.1;

clear

echo  $yellow

echo 'loading..........\';

sleep 0.1;

clear

echo  $cyan

echo 'Loading..........-';

sleep 0.1;

clear

echo  $red

echo "lOading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding............-';

sleep 0.1;

clear

echo  $yellow

echo 'loaDing.............\';

sleep 0.1;

clear

echo  $cyan

echo "loadIng............./";

sleep 0.1;

clear 

echo  $red

echo "loading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding..........-';

sleep 0.1;

clear

echo  $yellow

echo 'lOading..........\';

sleep 0.1;

clear

echo  $cyan

echo "Loading........../";

sleep 0.1;

clear

echo  $green

echo "loAding........../";

sleep 0.1;

clear

echo  $yellow

echo 'loaDing..........-';

sleep 0.1;

clear

echo  $cyan

echo 'loadIng..........\';

sleep 0.1;

clear

echo  $red

echo "loadiNg........../";

sleep 0.1;

clear

echo  $green

echo "loadinG..........-";

sleep 0.1;

clear

echo  $yellow

echo 'loading..........\';

sleep 0.1;

clear

echo  $cyan

echo 'Loading..........-';

sleep 0.1;

clear

echo  $red

echo "lOading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding............-';

sleep 0.1;

clear

echo  $yellow

echo 'loaDing.............\';

sleep 0.1;

clear

echo  $cyan

echo "loadIng............./";

sleep 0.1;

clear 

echo  $red

echo "loading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding..........-';

sleep 0.1;

clear

echo  $yellow

echo 'lOading..........\';

sleep 0.1;

clear

echo  $cyan

echo "Loading........../";

sleep 0.1;

clear

echo  $green

echo "loAding........../";

sleep 0.1;

clear

echo  $yellow

echo 'loaDing..........-';

sleep 0.1;

clear

echo  $cyan

echo 'loadIng..........\';

sleep 0.1;

clear

echo  $red

echo "loadiNg........../";

sleep 0.1;

clear

echo  $green

echo "loadinG..........-";

sleep 0.1;

clear

echo  $yellow

echo 'loading..........\';

sleep 0.1;

clear

echo  $cyan

echo 'Loading..........-';

sleep 0.1;

clear

echo  $red

echo "lOading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding............-';

sleep 0.1;

clear

echo  $yellow

echo 'loaDing.............\';

sleep 0.1;

clear

echo  $cyan

echo "loadIng............./";

sleep 0.1;

clear 

echo  $red

echo "loading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding..........-';

sleep 0.1;

clear

echo  $yellow

echo 'lOading..........\';

sleep 0.1;

clear

echo  $cyan

echo "Loading........../";

sleep 0.1;

clear

echo  $green

echo "loAding........../";

sleep 0.1;

clear

echo  $yellow

echo 'loaDing..........-';

sleep 0.1;

clear

echo  $cyan

echo 'loadIng..........\';

sleep 0.1;

clear

echo  $red

echo "loadiNg........../";

sleep 0.1;

clear

echo  $green

echo "loadinG..........-";

sleep 0.1;

clear

echo  $yellow

echo 'loading..........\';

sleep 0.1;

clear

echo  $cyan

echo 'Loading..........-';

sleep 0.1;

clear

echo  $red

echo "lOading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding............-';

sleep 0.1;

clear

echo  $yellow

echo 'loaDing.............\';

sleep 0.1;

clear

echo  $cyan

echo "loadIng............./";

sleep 0.1;

clear 

echo  $red

echo "loading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding..........-';

sleep 0.1;

clear

echo  $yellow

echo 'lOading..........\';

sleep 0.1;

clear

echo  $cyan

echo "Loading........../";

sleep 0.1;

clear

echo  $green

echo "loAding........../";

sleep 0.1;

clear

echo  $yellow

echo 'loaDing..........-';

sleep 0.1;

clear

echo  $cyan

echo 'loadIng..........\';

sleep 0.1;

clear

echo  $red

echo "loadiNg........../";

sleep 0.1;

clear

echo  $green

echo "loadinG..........-";

sleep 0.1;

clear

echo  $yellow

echo 'loading..........\';

sleep 0.1;

clear

echo  $cyan

echo 'Loading..........-';

sleep 0.1;

clear

echo  $red

echo "lOading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding............-';

sleep 0.1;

clear

echo  $yellow

echo 'loaDing.............\';

sleep 0.1;

clear

echo  $cyan

echo "loadIng............./";

sleep 0.1;

clear 

echo  $red

echo "loading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding..........-';

sleep 0.1;

clear

echo  $yellow

echo 'lOading..........\';

sleep 0.1;

clear

echo  $cyan

echo "Loading........../";

sleep 0.1;

clear

echo  $green

echo "loAding........../";

sleep 0.1;

clear

echo  $yellow

echo 'loaDing..........-';

sleep 0.1;

clear

echo  $cyan

echo 'loadIng..........\';

sleep 0.1;

clear

echo  $red

echo "loadiNg........../";

sleep 0.1;

clear

echo  $green

echo "loadinG..........-";

sleep 0.1;

clear

echo  $yellow

echo 'loading..........\';

sleep 0.1;

clear

echo  $cyan

echo 'Loading..........-';

sleep 0.1;

clear

echo  $red

echo "lOading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding............-';

sleep 0.1;

clear

echo  $yellow

echo 'loaDing.............\';

sleep 0.1;

clear

echo  $cyan

echo "loadIng............./";

sleep 0.1;

clear 

echo  $red

echo "loading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding..........-';

sleep 0.1;

clear

echo  $yellow

echo 'lOading..........\';

sleep 0.1;

clear

echo  $cyan

echo "Loading........../";

sleep 0.1;

clear

echo  $green

echo "loAding........../";

sleep 0.1;

clear

echo  $yellow

echo 'loaDing..........-';

sleep 0.1;

clear

echo  $cyan

echo 'loadIng..........\';

sleep 0.1;

clear

echo  $red

echo "loadiNg........../";

sleep 0.1;

clear

echo  $green

echo "loadinG..........-";

sleep 0.1;

clear

echo  $yellow

echo 'loading..........\';

sleep 0.1;

clear

echo  $cyan

echo 'Loading..........-';

sleep 0.1;

clear

echo  $red

echo "lOading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding............-';

sleep 0.1;

clear

echo  $yellow

echo 'loaDing.............\';

sleep 0.1;

clear

echo  $cyan

echo "loadIng............./";

sleep 0.1;

clear 

echo  $red

echo "loading.........../";

sleep 0.1;

clear

echo  $green

echo 'loAding..........-';

sleep 0.1;

clear

echo  $yellow

echo 'lOading..........\';

sleep 0.1;

clear

echo  $cyan

echo "Loading........../";

sleep 0.1;

clear

echo  $green

echo "loAding........../";

sleep 0.1;

clear

echo  $yellow

echo 'loaDing..........-';

sleep 0.1;

clear
figlet " Wellcone" | lolcat
pkg install sl
sl
clear
figlet "Rusmana" | lolcat
sleep 2
echo "\033[34;1m+++++++++++++++++++++++++++++++++++++"
sleep 2
echo "\033[31;1m|   Author        : Rusmana         |"
sleep 2
echo "\033[32;1m|   kontak   wa   : 083879017166    |"
sleep 2
echo "\033[34;1m|   chanel youtube: andro 45        |"
sleep 2
echo "\033[31;1m|   facebook      : Rusmana         |"
sleep 2
echo "\033[31;1m|   Thanks To.    : D4RKF19         |"
sleep 2
echo "\033[34;1m+++++++++++++++++++++++++++++++++++++"
sleep 2
date | lolcat
sleep 3
echo "\033[31;1m[•]==========|•••••÷•••••|========[•]"
sleep 3
echo "\033[32;1m[+]-------------------------------[+]"
sleep 3
echo "\033[35;1m[1].Untuk Mencari Bug internet gratis"
sleep 3
echo "\033[32;1m[+]-------------------------------[+]"
sleep 3
echo "\033[34;1m[2].Untuk Mengecek Bug 200 ok nya"
sleep 3
echo "\033[32;1m[+]-------------------------------[+]"
sleep 2
echo "\033[31;1m[•]==========|•••••÷•••••|========[•]"
sleep 3
echo "\033[34;1m|•|+++++++++++++++++++++++++++++++|•|"
sleep 2
echo "\033[32;1mSilhkan ketik y untuk melihat caranya"
sleep 2
echo "\033[34;1m|•|+++++++++++++++++++++++++++++++|•|"
sleep 2
echo "\033[34;1m|•|+++++++++++++++++++++++++++++++|•|"
sleep 2
echo "\033[32;1m|•|Dan Ketik t Untuk quotes saya  |•|"
sleep 2
echo "\033[34;1m|•|+++++++++++++++++++++++++++++++|•|"
sleep 2
echo "\033[31;1m|•|+++++++++++++++++++++++++++++++|•|"
sleep 2
echo "\033[34;1m|•| Ketik [y/t]  • • • • • • • •  |•|"
sleep 2
echo "\033[31;1m|•|+++++++++++++++++++++++++++++++|•|"
sleep 2
echo "\033[31;1m|•| [00]. Exit   • • • • • • • •  |•|"
sleep 2
echo "\033[34;1m|•|+++++++++++++++++++++++++++++++|•|"
sleep 2
echo "\033[32;1m╭──=>>"
read -p "╰────>root@Rusmana~> Pilih NO :" rus
if [ $rus = y ] || [ $rus = ya ];then
clear
echo "\033[32;1mOke Cara Kerjanya kalian tinggal memasukan"
sleep 1
echo "\033[34;1mbug host nya yg mau kita eksekusi"
sleep 1
echo "\033[31;1mcontoh bug nya misal app-manga.trebenow.tv"
sleep 1
echo "\033[32;1mlalu kalian masukan bug nya terus klik enter"
sleep 1
echo "\033[34;1mdan tunggu beberapa menit hingga bug nya"
sleep 1
echo "\033[31;1mSelesai di exsekusi"
sleep 15
sh bug.sh
clear
fi

if [ $rus = t ] || [ $rus = tidak ];then
clear
echo "\033[31;1mSalam Anak Bangsa anak muda berkarya bukan bergaya"
sleep 5
echo "\033[32;1mCowok keren tanpa asap roko"
sleep 3
echo "\033[34;1mGenerasi muda penerus bangsa"
sleep 2
echo "\033[31;1mGenerasi muda bebas NARKOBA"
sleep 2
echo "\033[35;1mCoder : Rusmana belajar secara otodidak"
sleep 3
echo "\033[34;1mSeorang pelajar smk jurusan TKJ Swasta bisa apa :("
sleep 3
echo "\033[31;1mbelajar tentang Hadware bukan sofware"
sleep 2
echo "\033[34;1mPemenang Adalah Orang Yg Berani Untuk Gagal"
sleep 2
echo "\033[35;1mSemoga NKRI kedepannya bisa menjadi negara yg maju"
sleep 3
echo "\033[32;1mmungkin itu saja yg dapat saya sampaikan"
sleep 3
echo "\033[31;1msemoga bermanfaaat dan gunakan dengan bijak"
sleep 2
echo "\033[32;1mWassalamu'alaikum wr.wb..."
sleep 5
clear
sh bug.sh
fi

if [ $rus = 01 ] || [ $rus = 1 ];then
clear
echo "\033[35;1mAssalamu'alaikum wr.wb.. jgn lupa berdo'a dl biar work"
sleep 3
apt update && apt upgrade
apt install tsu 
apt install nmap
apt install wget
apt install curl
clear
figlet "Rusmana" | lolcat
sleep 2
echo "\033[34;1m++++++++++++++++++++++++++++++++++++"
sleep 2
echo "\033[31;1m|   Author        : Rusmana        |"
sleep 2
echo "\033[32;1m|   kontak   wa   : 083879017166   |"
sleep 2
echo "\033[34;1m|   chanel youtube: andro 45       |"
sleep 2
echo "\033[31;1m|   facebook      : Rusmana        |"
sleep 2
echo "\033[34;1m++++++++++++++++++++++++++++++++++++"
sleep 1
date | lolcat
sleep 2
echo "\033[34;1mSilahkan salin ini : nmap -p 80 --script dns-brute.nse"
sleep 2
echo "\033[32;1mDan di belakangnya isi dgn bug yg ingin kita ekseskusi"
sleep 2
echo "\033[34;1mContoh : nmap -p 80 --script dns-brute.nse bbm.me"
sleep 2
echo "\033[32;1mLalu salin dan tempel di bawah dan tekan enter"
sleep 2
echo "\033[31;1mTunggu beberapa menit sampai selesai :)"
sleep 3
echo "\033[34;1m[•]++++++++++++++++++++++++++++++++++++++++++++++++[•]"
echo "\033[32;1mJika ingin kembali ke menu utama ketik ini sh bug .sh"
echo "\033[34;1m[•]++++++++++++++++++++++++++++++++++++++++++++++++[•]"
sleep 5
fi

if [ $rus = 02 ] || [ $rus = 2 ];then
clear
figlet "Rusmana" | lolcat
sleep 2
echo "\033[34;1m++++++++++++++++++++++++++++++++++++"
sleep 2
echo "\033[31;1m|   Author        : Rusmana        |"
sleep 2
echo "\033[32;1m|   kontak   wa   : 083879017166   |"
sleep 2
echo "\033[34;1m|   chanel youtube: andro 45       |"
sleep 2
echo "\033[31;1m|   facebook      : Rusmana        |"
sleep 2
echo "\033[34;1m++++++++++++++++++++++++++++++++++++"
sleep 2
date | lolcat
sleep 2
echo "\033[36;1mUntuk mengetahui bug nya 200 ok atau tidak bisa kalian cek"
sleep 2
echo "\033[34;1mCaranya Salin ini : curl -I"
sleep 2
echo "\033[34;1mTerus yg plg belakang di isi dgn bug yg kita dapat tadi"
sleep 2
echo "\033[32;1mContoh : curl -I play.hooq.tv"
sleep 2
echo "\033[32;1mlalu salin dan tempel di bawah lalu tekan enter"
sleep 2
echo "\033[34;1mterus begitu sampai kalian mendapat bug yg 200 ok"
sleep 2
echo "\033[32;1mJika ingin kembali ke menu sebelum nya ketik ini sh bug.sh"
sleep 5
fi

if [ $rus = 00 ] || [ $rus = 0 ];then
clear
echo "\033[32;1mSelamat mencoba kembali :)"
sleep 3
pkg install cmatrix
cmatrix 
fi
