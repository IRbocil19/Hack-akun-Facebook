#!/usr/bin/bash
#usr/bin/berkarya
#Coders:Rusmana
#Aku sayang kamu Reni Martini [Iren anya]
#semoga kita bisa bertemu amiin

clear
figlet "Rusmana" | lolcat

	echo """
	\033[34;1m
[•]==========================================[•]
 # quotes   :Salam Anak Bangsa     °  °   °   #
 # Coders   :Rusmana        °    °  °  °      #
 # kontax   :083879017166      °     °    °   #
 # Thanks To:Mr.R|﴾ஓீ͜ঔৣ͡D4RKF19ঔৣ͡ஓீ͜ঔৣ͡﴿|minami     #
 # Hacker_alicia|Mr.McA.404|MR.J4K1 404 3ROR  #
 # xNot_Found|Zuhria|/.M.Dafv.\|Mr_t3v!0n     #
 # Thanks To:All Memer TERMUX TOOLS-ID  °  °  #
 # Thanks To:Teman²Ku semua          °    °   #
[•]==========================================[•]

           ╔┓┏╦━━╦┓╔┓╔━━╗
           ║┗┛║┗━╣┃║┃║X X║
           ║┏┓║┏━╣┗╣┗╣╰╯║
           ╚┛┗╩━━╩━╩━╩━━╝
     
           【️++++++++++++++++++++】️
              [  TOOLS TERMUX  ]
           【️++++++++++++++++++++】️

date | lolcat
[+]=========[•••••[==÷==]•••••]=======[+]
sleep 2
☒️-------------------------------------☒️
===>[01] TELKOMSEL 
sleep 2
☒️-------------------------------------☒️	
sleep 2  
===>[02] PHD 
sleep 2
☒️-------------------------------------☒️			  
===>[03] TOKOPEDIA 
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[04] Grab 
sleep 2
☒️-------------------------------------☒️	
sleep 2			  
===>[05] JD.ID
sleep 2
☒️-------------------------------------☒️  
sleep 2
===>[06] Call-Tokopedia
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[07] BOM-Gmail 
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[08] Lazymux 
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[09] CNK--Spam 
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[10] DDOS-HAMMER 
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[11] Bobol Wifi(root)
sleep 2
☒️-------------------------------------☒
sleep 2
===>[12] INSTABOT 
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[13] FACEBOOK BRUTERFORCE
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[14] LINUX KATOLIN
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[15] Menghias Termux dgn Cowsay
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[16] Hack akun Instagram
☒️-------------------------------------☒️
sleep 2
===>[17] Bot Komen Facebook
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[18] RED-HAWK
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[19] Musikan di Termux
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[20] Browsing Di Termux
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[21] Telponan di Termux
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[22] inpormasi android kamu
sleep 2
☒️-------------------------------------☒️
sleep 2
==>[23] Menghapus kata d atas termux
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[24] Cara Install WEBSPLOIT
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[25] Hack Facebook metode MBF
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[26] Install Tools Mr.Rv1
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[27] Install Tools Mr.Rv2
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[28] Cara Install D-Tect TOOLS
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[29] Cara membuat virus
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[30] Crack Pasword HASH MD5 v.1
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[31] Crack Pasword HASH MD5 v.2
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[32] Install Metasploit no.root
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[33] Install SQL-MAP
sleep 2
☒️-------------------------------------☒️
sleep 2
===>[34] Cara Melacak IP
sleep 2
☒️-------------------------------------☒️
sleep 2
===[35] Mencari Admin Panel&Pinder
sleep 2
☒️-------------------------------------☒️
sleep 1
[•]==================================[•]
sleep 3
☒️-------------------------------------☒️
    ===[ ketik Y untuk kembali :) ]==
☒️-------------------------------------☒️
      ========[00]===>[exit]<====
☒️-------------------------------------☒️	
sleep2		  
Sialahkan pilih tools yg mau di gunakan
       Gunakan dengan bijak
   """ | lolcat 
   read -p "root@rus~>Pilih no :" yo

   if [ $yo = 01 ] || [ $yo = 1 ];then
   clear
   figlet "Rusmana" | lolcat
   php telkomsel.php
   fi
   if [ $yo = 02 ] || [ $yo = 2 ];then
   clear
   figlet "Rusmana" | lolcat
   php phd.php
   fi
   if [ $yo = 03 ] || [ $yo = 3 ];then
   clear
   figlet "Rusmana" | lolcat
   php tokped.php
   fi
   if [ $yo = 04 ] || [ $yo = 4 ];then
   clear
   figlet "Rusmana" | lolcat
   python2 spammer.py
   fi
   if [ $yo = 05 ] || [ $yo = 5 ];then
   clear
   toilet "Rusmana" | lolcat
   php jdid.php
   fi 
   if [ $yo = 06 ] || [ $yo = 6 ];then
   clear
   toilet "Rusmana" |lolcat
   php run.php
   fi
   if [ $yo = 07 ] || [ $yo = 7 ];then
   clear
   toilet "Rusmana" | lolcat
   python2 lazada.py
   fi
   
   if [ $yo = 08 ] || [ $yo = 8 ];then
   apt update && apt upgrade
   apt install git
   git clone https://github.com/Gameye98/Lazymux
   cd Lazymux
   ls
   python2 lazymux.py
   clear
   fi
   
   if [ $yo = 09 ] || [ $yo = 9 ];then
   apt upgrade && apt update
   apt install git 
   git clone https://github.com/hatakecnk/cnkspam
   cd cnkspam
   sh install.sh
   sh cnk.sh
   fi

   if [ $yo = 10 ] || [ $yo = 10 ];then
   pkg update
   pkg upgrade
   pkg install python
   pkg install git
   git clone https://github.com/cyweb/hammer
   cd hammer
   python hammer.py
   fi
   
   if [ $yo = 11 ] || [ $yo = 11 ];then
   apt update
   apt upgrade
   pkg install git
   git clone https://github.com/hatakecnk/wifi-hacker
   cd wifi-hacker
   chmod +x wifi-hacker.sh
   ./wifi-hacker.sh
   fi
   
   if [ $yo = 12 ] || [ $yo = 12 ];then
   apt update && apt upgrade -y
   pkg install nodejs
   git clone https://github.com/hatakecnk/INSTABOT
   cd INSTABOT
   unzip node_modules.zip
   node index.js
   fi
   
   if [ $yo = 13 ] || [ $yo = 13 ];then
   apt update  
   apt upgrade 
   apt install python2 
   apt install python2-dev 
   apt install wget 
   pip2 install mechanize
   cd/storage/emulated/0
   python2 fbbrute.py
   storage/emulated/0/password.txt
   fi
   
   if [ $yo = 14 ] || [ $yo = 14 ];then
   Pkg install git
   Pkg install python2
   Pkg install gnupg
   Pkg install nano
   git clone https://github.com/LionSec/katoolin.git
   cd  katoolin
   nano katoolin.py
   python2 katoolin.py
   fi
   
   if [ $yo = 15 ] || [ $yo = 15 ];then
   pkg update && pkg upgrade
   pkg install ruby cowsay toilet figlet
   pkg install neofetch
   pkg install nano
   gem install lolcat
   cd ../usr/etc
   nano bash.bashrc
   fi
   
   if [ $yo = 16 ] || [ $yo = 16 ];then
   apt update && apt upgrade -y
   apt install nodejs git
   cd Instagram-Private-Tools
   node index.js
   git clone https://github.com/ccocot/Instagram-Private-Tools.git
   npm install
   fi
   
   if [ $yo = 17 ] || [ $yo = 17 ];then
   pkg update && pkg upgrade
   pkg install git
   pkg install python2
   pip2 install mechanize
   git clone https://github.com/Senitopeng/Botkomena.git
   cd Botkomena
   python2 botkomena.py
   fi
   
   if [ $yo = 18 ] || [ $yo = 18 ];then
   apt update
   apt install git
   git clone https://github.com/Tuhinshubhra/RED_HAWK
   cd RED_HAWK
   chmod +x rhawk.php
   apt install php
   ls
   php rhawk.php
   fi
   
   if [ $yo = 19 ] || [ $yo = 19 ];then
   pkg install mpv 
   mpv/sdcard/lagu.mp3 
   /sdcard/ bisa di ganti sesuai letak musik
   fi
   
   if [ $yo = 20 ] || [ $yo = 20 ];then
   pkg install w3m
   w3m www.google.com
   Linknya bsa diubah
   fi
   
   if [ $yo = 21 ] || [ $yo = 21 ];then
   apt update && apt upgrade
   pkg install termux-api
   termux-telephony-call nomornya
   fi
   
   if [ $yo = 22 ] || [ $yo = 22 ];then
   pkg install neofetch
   neofetch
   fi
   
   if [ $yo = 23 ] || [ $yo = 23 ];then
   rm -r ../usr/etc/motd
   cp -rf BOM /$HOME && cd
   fi
   
   if [ $yo = 24 ] || [ $yo = 24 ];then
   apt update && upgrade -y
   apt install python2
   pip2 install scapy
   git clone https://github.com/The404Hacking/websploit.git
   cd websploit
   chmod 777 *.py
   python2 websploit.py
   fi
   
   if [ $yo = 25] || [ $yo = 25 ];then
   pkg install python2
   pkg install git
   git clone https://github.com/pirmansx/mbf
   cd mbf/
   pip2 install mechanize
   python2 MBF.py
   fi
   
   if [ $yo = 26 ] || [ $yo = 26 ];then
   apt update && apt upgrade
   apt install figlet
   apt install lolcat
   apt install git
   git clone https://github.com/Mr-R225/Mr.Rv1
   cd Mr.Rv1
   sh Mr.Rv1.sh 
   fi
   
   if [ $yo = 27 ] || [ $yo = 27 ];then
   apt update
   apt upgrade
   apt install git
   apt install figlet
   gem install lolcat
   git clone https://github.com/Mr-R225/Mr.Rv2
   cd Mr.Rv2
   sh Mr.Rv2.sh
   fi
   
   if [ $yo = 28 ] || [ $yo = 28];then
   apt install git
   apt install python2
   git clone https://github.com/shawarkhanethicalhacker/D-TECT
   ls
   cd D-TECH
   chmod +x d-tect.py
   python2 d-tect.py
   fi
   
   if [ $yo = 29 ] || [ $yo = 29 ];then
   cd Vbug/vbug.py
   cd /storage/emulated/0/Vbug
   cd vbug
   Python2 vbug.py
   fi
   
   if [ $yo = 30 ] || [ $yo = 30 ];then
   apt update && apt upgrade
   pkg install git
   git clone https://github.com/FajriHidayat088/FHX-Hash-Killer/
   cd FHX-Hash-Killer
   python2 FHXHashKiller.py
   fi
   
   if [ $yo = 31 ] || [ $yo = 31 ];then
   git clone https://github.com/UltimateHackers/Hash-Buster
   cd Hash-Buster
   python2 hash.py
   pkg install irssi
   irssi (enter)
   /connect chat.freenode.net
   /nick oki
   /join #mrmaze
   fi
   
   if [ $yo = 32 ] || [ $yo = 32 ];then
   apt update && apt upgrade
   apt install curl
   curl -LO https://raw.githubusercontent.com/Hax4us/Metasploit_termux/master/metasploit.sh
   chmod +x metasploit.sh
   ./metasploit.sh
   fi
   
   if [ $yo = 33 ] || [ $yo = 33 ];then
   apt update
   apt install python
   apt install python2
   apt install git
   git clone https://github.com/sqlmapproject/sqlmap
   cd sqlmap
   Python2 sqlmap.py
   fi
   
   if [ $yo = 34 ] || [ $yo = 34 ];then
   apt install python git
   git clone https://github.com/maldevel/IPGeoLocation.git
   cd IPGeoLocation
   chmod +x ipgeoLocation.py
   pip install -r requirements.txt
   python ipgeolocation.py -m
   python ipgeolocation.py -t http://www.google.com
   fi

   if [ $yo = 35 ] || [ $yo = 35 ];then
   pkg install git
   git clone https://github.com/Techzindia/admin_penal
   cd admin_penal
   chmod +x admin_panel_finder.py
   python2 admin_panel_finder.py
   fi
   
   if [ $yo = 00 ] || [ $yo = 0 ];then
   fi
   
   clear
   echo "\033[35;1mSemoga bermanpaat dan gunakan dengan bijak :)"
   sleep 1
   echo "\033[32;1mJika ingin kembali lagi silahkan ketik sh rus.sh"
   sleep 1
   echo "\033[31;1mSalam Anak Bangsa"
   sleeo 2
   echo "\033[34;1mAnak Muda Berkarya Bukan Bergaya"
   sleep 3
   echo "\033[36;1mwasaalamu'alaikum wr.wb.." | lolcat
   sleep 1
   
   if [ $Y = Y ] || [ $Y = y ];then
   pkg install cmatrix
   cmatrix
   fi
  exit
  
 fi
    
if [ $Y = N ] || [ $Y = n ]
then
clear
sh rus.sh
fi
