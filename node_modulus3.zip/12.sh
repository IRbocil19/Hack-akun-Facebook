#!/usr/bin/bash
#usr/bin/berkarya
#Coders:Rusmana
#Aku sayang kamu Rani Martini [Iren anya]
#semoga kita bisa bertemu amiin

clear
figlet "Rusmana" | lolcat

	echo """
	\033[34;1m
[•]============================================[•]
	quotes   :Salam Anak Bangsa
	Coders   :Rusmana
	kontax   :083879017166
	Thanks To:Mr.R|﴾ஓீ͜ঔৣ͡D4RKF19ঔৣ͡ஓீ͜ঔৣ͡﴿|minami
	 Hacker_alicia|Mr.McA.404|MR.J4K1 404 3ROR
	Thanks To:Teman²Ku semua
[•]============================================[•]
	"""
	
	echo """"
	if
	pkg install sl
	sl
	fi
	clear
   ========[01]--===>-=[TELKOMSEL]=-<===---			  
   ========[02]-----===>-=[PHD]=-<===------							  
   ========[03]--===>-=[TOKOPEDIA]=-<===---
   ========[04]-----===>-=[Grab]=-<===-----							  
   ========[05]-----===>-=[JD.ID]=-<===----			  
   ========[06]===>-=[Call-Tokopedia]=-<===
   ========[07]---===>-=[BOM-Gmail]=-<===--	
   ========[08]- - =[Autolike-Facebook]=- -
   ========[09]- - - - - -=[DDOS]=- - - - -
   ========[10]- - - --=[Bot_konmen]=- - --
   ========[11]- - --=[Hack-Facebook]=- - -
[•]============================================[•]
   ========[00]===>[exit]<=====
   clear
   Sialahkan pilih tools yg mau di gunakan
   Gunakan dengan bijak
   """ | lolcat 
   read -p "Pilih no :" yo

   if [ $yo = 01 ] || [ $yo = 1 ];then
   clear
   figlet "Rusmana" | lolcat
   php telkomsel.php
   fi
   if [ $yo = 02 ] || [ $yo = 2 ];then
   clear
   figlet "Rusmana" | lolcat
   php phd.php
   fi
   if [ $yo = 03 ] || [ $yo = 3 ];then
   clear
   figlet "Rusmana" | lolcat
   php tokped.php
   fi
   if [ $yo = 04 ] || [ $yo = 4 ];then
   clear
   figlet "Rusmana" | lolcat
   python2 spammer.py
   fi
   if [ $yo = 05 ] || [ $yo = 5 ];then
   clear
   toilet "Rusmana" | lolcat
   php jdid.php
   fi 
   if [ $yo = 06 ] || [ $yo = 6 ];then
   clear
   toilet "Rusmana" |lolcat
   php run.php
   fi
   if [ $yo = 07 ] || [ $yo = 7 ];then
   clear
   toilet "Rusmana" | lolcat
   python2 lazada.py
   fi
   if [ $yo = 08 ] || [ $yo = 8 ];then
   clear
   toilet "Rusmana" | lolcat
   php autolike.php
   fi
   if [ $yo = 09 ] || [ $yo = 9 ];then
   clear
   toilet "Rusmana" | lolcat
   ddos.py
   fi
   if [ $yo = 10 ] | [ $yo = 10 ];then
   clear
   toilet "Rusmana"
   botkomen.py
   fi
   if [ $yo = 11 ] | [ $yo = 11 ];then
   clear
   toilet "Rusmana"
   mbf.py
   fi
   clear
   echo "jika ingin mengunakan nya lagi ketik saja sh rus.sh
   semoga bermanfaat :)" | lolcat
   fi
   if [ $yo = 0 ] || [ $yo = 0 ];then
   pkg install cmatrix
   cmatrix
   fi
