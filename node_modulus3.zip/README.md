# Rusmana
ingin menjadi seorang programer yg succes
dan bisa membanggakan kedua org tua 
and NKRI
