

#!/usr/bin/bash
#apa lu lihat-lihat gue njing..
#asw

clear

echo """
    
                 \033[96mMMMMMM
                 MMMMMM
                 MMMMMM """
echo """         \033[91m MMMMMMMMMMMMMMMMMMMM
          TT    TT    TT    TT
          TTTT  TT    TT    TT
          TT    TT    TT    TT
          TTTT  TT    TT    TT
          TT    TT    TT    TT
          MMMMMMMMMMMMMMMMMMMM """ | lolcat
echo """                 \033[96mMMMMMM
               MMMMMMMMMM
             MMMMMMMMMMMMMM
               \033[0mMMMMMMMMMM
               MMMMMMMMMM
               MMMMMMMMMM
               MMMMMMMMMM
               MMMMMMMMMM
               MMMMMMMMMM"""
sleep 1
echo """\033[96m
     <={~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~}=>
         Author  = 
                  Nama:~Fahri A.R
                  Nick:~DroidX
                       ~YONDAIME09 X
         Code    = Bash
         Contact = +6289606402413
         Date    = 29-07-2018
     <={~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~}=>""" |lolcat
echo """              \033[0m MMMMMMMMMM
               MMMMMMMMMM
                MMMMMMMM
                 MMMMMM
                  MMMM
                   MM""" 
date | lolcat
echo "\033[93m"
echo "Ketik \033[96mL \033[93muntuk lanjut"
read -p "Ketik :" L ;

if [ $L = L ] || [ $L = l ]
then
clear
toilet -f shadow -F gay "T.DYF"
echo "\033[96m"
echo """
 ~~~~~~~~~~~~~~~~| WellCome |~~~~~~~~~~~~~~~~~~~
(                 Thanks To :                   )
 ) ROBOSKIJr404 || Mr.Lee || 25JuL || X#yz     (
(  GrimX72 || White System || T393 Cyber        )
 ) itsZnine7 || Cyrus || Nr.4C3N9 ||           (
(  Mr.Catur || Cyb3r_M0oN || L0L1_T3RS4K1TI     )
 ) Under!Score X || Organz69 || Kuro Cyber     (
(  Mr.D34D_3Y35 || Mr.Black Rabbit || Mr.Percil )
 ) Mr.YNXN Cyber || Mr.zx04 || Mr.ruben2019    (
(  Pstar7 || M1KM.R4R || C0dex.3rr              )
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
       """ | lolcat
sleep 2
echo "\033[93mSelamat Datang DiTool DYF :)"
echo """Tools belum mencapai 300 Tapi Secepatnya
akan saya update """
sleep 3
echo "\033[94manda akan menginstall 300 Tools"
sleep 1
echo "\033[96mpastikan penyimpanan anda cukup "
sleep 2
echo "\033[92mMungkin Ini memerlukan waktu yg lama"
sleep 3
echo "\033[93mY \033[91m[\033[93mLanjut\033[91m] \033[94m/ \033[93mN \033[91m[\033[93mTidak\033[91m] \033[93m"
sleep 1
fi
read -p "[Y / N ] :" Y ;

if [ $Y = Y ] || [ $Y = y ]
then
clear
echo "\033[96m"
apt update&&apt upgrade -y
pkg install git -y php -y toilet -y
pkg install python -y python2 -y python3 -y
pkg install curl -y
pkg install figlet -y cowsay -y vim
pkg install ruby -y wget gem
pip install requests
pip2 install mechanize
git clone https://github.com/hatakecnk/xNot_Found
git clone https://github.com/droidxerror/T.HUNTERv2
git clone https://github.com/droidxerror/SpamISH
git clone https://github.com/droidxerror/T.DEF-09
git clone https://github.com/Gameye98/santet-online
git clone https://github.com/Ubaii/script-deface-creator
git clone https://github.com/Gameye98/Lazymux.git
git clone https://github.com/zerosvn/ktpkkgenerate
git clone https://github.com/Xi4u7/A-Rat.git
git clone https://github.com/cyweb/hammer
git clone https://github.com/4L13199/LITEDDOS
git clone https://github.com/UltimateHackers/ReconDog
git clone https://github.com/Rusmana-ID/rus
git clone https://github.com/rootM3eX/VTools
git clone https://github.com/evait-security/weeman.git
git clone https://github.com/T14RB373T/TelSpam
git clone https://github.com/pirmansx/mbf
git clone https://github.com/albertoanggi/xl-py
git clone https://github.com/Junior60/vbug
git clone https://github.com/Cvar1984/LiteOTP
git clone https://github.com/LionSec/katoolin.git
pkg install nano
pkg install gnupg
git clone https://github.com/zanyarjamal/xerxes
apt install clang
git clone https://github.com/dotfighter/torshammer.git
curl -L0 https://raw.githubusercontent.com/Hax4us/Metasploit_termux
git clone https://github.com/sqlmapproject/sqlmap
git clone https://github.com/b3-v3r/Hunner
git clone https://github.com/maldevel/IPGeoLocation.git
pip install -r requirements.txt
git clone https://github.com/Techzindia/admin_penal
git clone https://github.com/4shadoww/hakkuframework
git clone https://github.com/Tuhinshubhra/RED_HAWK
git clone https://github.com/shawarkhanethicalhacker/D-TECT
git clone https://github.com/mrcakil/Mrcakil.git
pip install scapy 
git clone https://github.com/The404Hacking/websploit.git
git clone https://github.com/esc0rtd3w/wifi-hacker
pkg install perl
git clone https://github.com/x-xsystm/account
git clone https://github.com/Amriez/gcospam
git clone https://github.com/4L13199/LITESPAM
git clone https://github.com/Xeit666h05t/CrewBot
git clone https://github.com/avramit/instahack
git clone https://github.com/XG77Z10/Google-Dork
pip2 install termcolor
git clone https://github.com/AnonHackerr/toolss.git
apt install nodejs
git clone https://github.com/anadhelf/ig
npm install
node ffauto
git clone https://github.com/x-xsystm/maps.git
pkg install irssi
pkg install w3m
pkg install neofetch
pip install youtube_dl
apt install mpv
git clone https://github.com/Senitopeng/BotKomena
git clone https://github.com/UltimateHackers/Strike
git clone https://github.com/Ciku370/OSIF
git clone https://github.com/googleinurl/SCANNER-INURLBR
git clone https://github.com/UndeadSec/SocialFish
git clone https://github.com/Harisgitama/login-termux
git clone https://github.com/QiubyZ/QFloodSms
git clone https://github.com/QiubyZ/QJDID
git clone https://github.com/SIIL3NT/spam
git clone https://github.com/haijuga7/New-Spammer
pkg install python2-dev clang libxml2
git clone https://github.com/UltimateHackers/Blazy.git
git clone https://github.com/DedSecCyber/scorpion
git clone https://github.com/kereh/Ip-gathering
git clone https://github.com/zanyarjamal/Email-bomber
git clone https://github.com/Anon-Exploiter/SiteBroker
git clone https://github.com/Gameye98/SpazSMS
git clone https://github.com/kereh/Kuyang-Tool
git clone https://github.com/SkyKnighTeam/IP-TRACK
git clone https://github.com/Cvar1984/Kawai-Botnet
git clone https://github.com/SkyKnight-Team/TouchUrl
git clone https://github.com/Cvar1984/pemulungBTC
git clone https://github.com/DedSecCyber/HPAS1369
git clone https://github.com/Cvar1984/Deface
git clone https://github.com/kuburan/txtool.git
git clone https://github.com/kuburan/Spyder
git clone https://github.com/kereh/Findip
git clone https://github.com/kereh/IGP
git clone https://github.com/kereh/VulnScaner
pip2 install tqdm
pip2 install fbchat
git clone https://github.com/Senitopeng/Spamchat
pip install tweepy
git clone https://github.com/mtmxlog/tweetbot-max
git clone https://github.com/urbanadventurer/WatWeb
git clone https://github.com/samyoyo/flux
git clone https://github.com/md5-password-cracker.js
git clone https://github.com/Imammino/jwt-cracker
git clone https://github.com/s0md3v/Hash-Buster
git clone https://github.com/coding-shadow/facebook_cracker
git clone https://github.com/coding-shadow/admin_panel_finder
git clone https://github.com/Hood3dRob1n/BinGoo
git clone https://github.com/Cvar1984/Termux-A.git
git clone https://github.com/Senitopeng/GadoGado
git clone https://github.com/verluchie/termux-lazysqlmap
git clone https://github.com/MrKeepSmile/errorcybertool
wget -0 tuyul.php https://pastebin.com/raw/3ERZV3nL
git clone https://github.com/m4II0k/WAScan
git clone https://github.com/kereh/MultiSpam
git clone https://github.com/Kawai-Botnet
git clone https://github.com/Autoreaction
git clone https://github.com/Gameye98/OWScan
git clone https://github.com/Gameye98/AstraNmap
git clone https://github.com/Gameye98/Auxscan2.0
git clone https://github.com/Gameye98/Black-Hydra
git clone https://github.com/Ciku370/ipddos
git clone https://github.com/Ciku370/hasher
git clone https://github.com/senitopeng/PhisingGame
git clone https://github.com/UltimateHackers/Breacher
git clone https://github.com/Lexiie/SosialFish
git clone https://github.com/mebus/cupp
git clone https://github.com/ciku370/ko-dork
git clone https://github.com/ciku370/lhst
git clone https://github.com/Screetsec/TheFatRat
git clone https://github.com/Dionach/CMSmap
git clone https://github.com/JamesAndresCM/Brute_force_gmail
git clone https://github.com/Hax4us/Nethunter-In-Termux
wget https://pastebin.com/raw/sPpJRCZ -0 lokomedia.php
git clone https://github.com/rezasp/joomscan
git clone https://github.com/kereh/Fucking-Rat
git clone https://github.com/m4ll0k/Infoga
git clone https://github.com/rand0m1ze/ezsploit
git clone https://github.com/nmilosev/termux-fedora
git clone https://github.com/maurosoria/dirsearch
git clone https://github.com/zdresearch/0WASP-Nettacker
git clone https://github.com/whackhashoe/killr
git clone https://github.com/mrcakil/cok-Rat
git clone https://github.com/m4ll0k/SMBrute
git clone https://github.com/YukersCreew/BForce
git clone https://github.com/m4ll0k/WPSeku
git clone https://github.com/aryanrtm/Remote-Shell
git clone https://github.com/gshofficialgithubindonesia/autoreport-fb
git clone https://github.com/4L13199/meTAInstall
git clone https://github.com/aryanrtm/WP-Hunter
git clone https://github.com/verluchie/instabot.py
git clone https://github.com/verluchie/bot-exploiter
git clone https://github.com/maldevel/gdog
git clone https://github.com/rezasp/vbscan
git clone https://github.com/Xi4u7/BlackNmap
git clone https://github.com/Screetsec/Brutal
git clone https://github.com/Screetsec/Dracnmap
git clone https://github.com/zanyarjamal/DataSploit
git clone https://github.com/zanyarjamal/zambie
git clone https://github.com/the-c0d3r/pynmap
git clone https://github.com/zanyarjamal/IP-Locator
git clone https://github.com/the-c0d3r/port-lookup
git clone https://github.com/LionSec/wifresti
git clone https://github.com/evait-security/ClickNRoot
git clone https://github.com/kereh/BlackMail
git clone https://github.com/haijuga7/Dec-Enc-Hash
git clone https://github.com/kereh/BlackTrack
git clone https://github.com/pirmansx/myenc
git clone https://github.com/Rajkumrdusad/Tool-Kit
git clone https://github.com/cyweb/server_domains
git clone https://github.com/UltimateHackers/hue
git clone https://github.com/UltimateHackers/Decodify
git clone https://github.com/UltimateHackers/Entropy
git clone https://github.com/4shadoww/RemBot
git clone https://github.com/Tuhinshubhra/Facebook-Video-Downloader
git clone https://github.com/4shadoww/stabilizerbot
git clone https://github.com/shawrkhanethicalhacker/PHP-BackConnector
git clone https://github.com/shawrkhanethicalhacker/csrfpocmaker
git clone https://github.com/DaffaTakarai/XEIT_Cyber
git clone https://github.com/Xeiit666h05t/BoxSosmed
git clone https://github.com/Xeiit666h05t/CrewBot
git clone https://github.com/avramit/CamStream-V3
git clone https://github.com/avramit/Instahack
git clone https://github.com/XG77Z10/Google-Dork
git clone https://github.com/bitcoin/bitcoin-wallet
git clone https://github.com/medbenali/CybersScan
git clone https://github.com/Gameye98/1337Hash
git clone https://github.com/Manisso/fsociety
git clone https://github.com/Senitopeng/TuyulBtn
git clone https://github.com/sullo/nikto
git clone https://github.com/sdrausty/termux-archlinux
apt install ncurses-utils
git clone https://github.com/st42/termux-sudo
git clone https://github.com/Neo-0li/termux-ubuntu
git clone https://github.com/Amriez/MamangKey
git clone https://github.com/mossberg/poet
git clone https://github.com/Anb3rSecID/Hashzer
git clone https://github.com/ikkebr/PyBozoCrack
git clone https://github.com/ekultek/pybelt
git clone https://github.com/lightos/credmap
git clone https://github.com/UndeadSec/EvilURL
git clone https://github.com/mrcakil/Mrcakil
git clone https://github.com/thegackingsage/hacktronian
git clone https://github.com/ihebski/angryFuzzer.git
git clone https://github.com/AnonHackerr/toolss
git clone https://github.com/rafalgolarz/termux-go
git clone https://github.com/Amriez/Bolang
git clone https://github.com/r00mars/XPL-SEARCH
git clone https://github.com/zigoo0/webpwn3r
git clone https://github.com/sysadminteam/IPscan
git clone https://github.com/sysadmimteam/NetKiller
git clone https://github.com/PentesterES/AndroidPINCrack
apt install nmap curl
curl -O http://override.waper.co/files/AndroZenmap/androzenmap.sh
git clone https://github.com/Hadesy2k/sqliv
git clone https://github.com/Cvar1984/Easymap
git clone https://github.com/AeonDave/sir
git clone https://github.com/Ubaii/Xshell
apt install lynx
git clone https://github.com/Anb3rSecID/sqlokmed
git clone https://github.com/Cvar1984/zones
git clone https://github.com/LOoLzeC/SH33LL
git clone https://github.com/reverse-shell/routersploit
pip2 install requests
git clone https://github.com/derv82/wifite
git clone https://github.com/wiire/pixiewps
git clone https://github.com/thehackingsage/Fluxion
git clone https://github.com/ustayready/CredSniper
202

git clone https://github.com/cabbagec/termux-ohmyzsh
git clone https://github.com/Gameye98/SpazSMS
git clone https://github.com/Amriez/ANRspam
git clone https://github.com/p4kl0nc4t/spammer-grab
git clone https://github.com/ALX-04/AVARspam
git clone https://github.com/v1s1t0r1sh3r3/airgeddon
git clone https://github.com/x-xsystm/genscript
git clone https://github.com/Amriez/ipmux
git clone https://github.com/joker25000/Devploit
git clone https://github.com/Cvar1984/sqlscan
git clone https://github.com/blackvkng/viSQL
git clone https://github.com/trustedsec/sosial-engineer-toolkit
git clone https://github.com/Moham3dRiahi/Th3inspector
git clone https://github.com/Amriez/GreenReaper
git clone https://github.com/atarantini/wpbf
wget https://pastebin.com/raw/LDvFvtUD -o comfabrik.php
git clone https://github.com/wpscanteam/wpscan
git clone https://github.com/commixproject/commix
git clone https://github.com/AlisamTechnology/ATSCAN
git clone https://github.com/reyammer/shellnoob
git clone https://github.com/verluchie/termux-lazysqlmap
git clone https://github.com/grafov/hulk
wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.zip
git clone https://github.com/senitopeng/Botkomena
git clone https://github.com/not404foundcyberteam/spam-mantan
git clone https://github.com/soracyberteam/cli-browser
git clone https://github.com/soracyberteam/bash-ransomware
git clone https://github.com/soracyberteam/face-hack
git clone https://github.com/Amriez/AOCDEFACE
git clone https://github.com/ciku370/WebKit
git clone https://github.com/pirmansx/hostcheker
git clone https://github.com/OffensivePython/Nscan
git clone https://github.com/ismailtasdelen/Anti-DDOS
git clone https://github.com/Harisgitama/termux-loginv2fx
git clone https://github.com/TUANB4DUT/T00LSINSTALLERv2
git clone https://github.com/rootM3eX/VTools
git clone https://github.com/4L13199/LITESPAM
git clone https://github.com/re4lity/PoC-Exploit
git clone https://github.com/sqlitebrowser/sqlitebrowser
git clone https://github.com/OffensivePython/Saddam
git clone https://github.com/kereh/Good_Terminal
git clone https://github.com/kereh/Deface-create
git clone https://github.com/kereh/HN-Installer
git clone https://github.com/Gameye98/Komodo
git clone https://github.com/torvalds/linux
echo """\033[91mDone.....
\033[96mTools Telah Terinstall :) 
\033[94mTerima Kasih Telah Menggunakan 
\033[92mTools Ini _/\_"""
exit
fi

if [ $Y = N ] || [ $Y = n ]
then
clear
sh 300.sh
fi
 
