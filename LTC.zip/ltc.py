#!/usr/bin/python

# Author : Rusmana
# Cita-Cinta : ingin menjadi developer and programer Aamiin


import sys
import time
import os
from platform import system

os.system("clear")
time.sleep(1)
os.system("clear")
print
print "   \033[32;1m[\033[34;1m+\033[32;1m] \033[34;1mModifykasi by \033[31;1m: \033[33;1mRusmana"
print "   \033[32;1m[\033[34;1m+\033[32;1m] \033[34;1mKontak WA \033[31;1m: \033[33;1m083879017166"
print "   \033[32;1m[\033[34;1m+\033[32;1m] \033[34;1mTelegram \033[31;1m: \033[33;1mhttps://t.me/Rusmana2"
print "   \033[32;1m[\033[34;1m+\033[32;1m] \033[34;1mTeam Termux \033[31;1m: \033[33;1mTERMUX TOOLS-ID"
print "   \033[32;1m[\033[34;1m+\033[32;1m] \033[34;1mTeam Cyber \033[31;1m: \033[33;1mBaby Cyber Mafia"
print
print "\033[32;1m       ..::[\033[31;1m!\033[32;1m] \033[31;1mNOTE \033[32;1m[\033[31;1m!\033[32;1m]::.. "
print "  \033[34;1maku buat ini cuman ingin"
print "              \033[34;1mbisa lebih mudah lagi"
print "  \033[34;1mdalam menuyulnya jadi aku "
print "              \033[34;1mtambahin pitur nya :)"
print "\033[32;1m     [\033[31;1m+\033[32;1m] \033[31;1mSalam Anak Bangsa \033[32;1m[\033[31;1m+\033[32;1m]"

time.sleep(1)
print
os.system("toilet -f pagga '  TUYUL LTC>' | lolcat")
print

def q():

	os.system("python main1.py " + z)
	print

def mnu():
	print "\033[31;1m    ..::[ \033[32;1mTOOLS NUYUL LTC \033[31;1m]::.. "
mnu()
print
print "     \033[33;1mex :(+62)"
z = raw_input("\033[32;1mINPUT NO.TELEGRAM NYA \033[31;1m: ")

q()
mnu()
sys.exit()




    
    
